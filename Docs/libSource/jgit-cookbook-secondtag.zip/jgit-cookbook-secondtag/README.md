jgit-cookbook
=============

Provides examples and code snippets for jgit Java Git implementation
